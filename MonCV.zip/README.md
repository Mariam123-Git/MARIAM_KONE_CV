#  Documentation du projet MonCV

##  Description
Ce projet a pour objectif de créer un **CV interactif et responsive** en HTML, CSS et JavaScript.  
Il met en avant le parcours, les compétences et les expériences professionnelles de l’utilisateur.



##Q8-  Dans la partie responsive au fur et à mesure qu'on change de taille de l'ecran la couleur change

🔗 **Mon CV en ligne est disponible à l’adresse suivante :**  
[https://mariam123-git.github.io/MARIAM_KONE_CV/](https://mariam123-git.github.io/MARIAM_KONE_CV/)
